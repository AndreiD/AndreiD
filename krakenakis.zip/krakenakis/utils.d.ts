export declare const getAccounts: () => string[][];
export declare const getTransactions: () => {
    keys: string;
    values: any[][];
};
